export const environment = {
  production: false,
  apiUrl: 'https://microcapital-ixtepec.com/api/v1',
  //apiUrl: 'http://localhost:3000/api/v1',
};