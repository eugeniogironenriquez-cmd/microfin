import { Component, OnInit, OnDestroy, inject, signal } from "@angular/core";
import { CommonModule, CurrencyPipe, DatePipe } from "@angular/common";
import { MatCardModule } from "@angular/material/card";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatTableModule } from "@angular/material/table";
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatSnackBar, MatSnackBarModule } from "@angular/material/snack-bar";
import { interval, Subscription } from "rxjs";
import { ApiService } from "../../core/index";
import { PdfDownloadService } from "../../core/pdf-download.service";
import * as XLSX from "xlsx";

@Component({
  selector: "app-payments-monitor",
  standalone: true,
  imports: [
    CommonModule,
    CurrencyPipe,
    DatePipe,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatTooltipModule,
    MatSnackBarModule,
  ],
  template: `
    <div class="page-header">
      <h1><mat-icon>monitor</mat-icon> Monitor de pagos del día</h1>
      <div class="header-actions">
        <button
          mat-stroked-button
          (click)="loadPayments()"
          [disabled]="loading()"
        >
          <mat-icon>refresh</mat-icon> Actualizar
        </button>
        <button
          mat-raised-button
          color="primary"
          (click)="exportExcel()"
          [disabled]="payments().length === 0"
        >
          <mat-icon>table_chart</mat-icon> Exportar Excel
        </button>
      </div>
    </div>

    <!-- KPI CARDS -->
    <div class="kpi-row">
      <div class="kpi kpi-green">
        <div class="kpi-left">
          <div class="kpi-label">Pagos registrados</div>
          <div class="kpi-value">{{ payments().length }}</div>
          <div class="kpi-sub">Hoy {{ today() }}</div>
        </div>
        <div class="kpi-icon"><mat-icon>payments</mat-icon></div>
      </div>
      <div class="kpi kpi-blue">
        <div class="kpi-left">
          <div class="kpi-label">Total cobrado</div>
          <div class="kpi-value">
            {{ totalCollected() | currency: "MXN" : "symbol" : "1.0-0" }}
          </div>
          <div class="kpi-sub">Capital + interés</div>
        </div>
        <div class="kpi-icon"><mat-icon>account_balance_wallet</mat-icon></div>
      </div>
      <div class="kpi kpi-amber">
        <div class="kpi-left">
          <div class="kpi-label">Moratorios</div>
          <div class="kpi-value">
            {{ totalLate() | currency: "MXN" : "symbol" : "1.0-0" }}
          </div>
          <div class="kpi-sub">Por atraso</div>
        </div>
        <div class="kpi-icon"><mat-icon>warning</mat-icon></div>
      </div>
      <div class="kpi kpi-purple">
        <div class="kpi-left">
          <div class="kpi-label">Clientes</div>
          <div class="kpi-value">{{ uniqueCustomers() }}</div>
          <div class="kpi-sub">Únicos atendidos</div>
        </div>
        <div class="kpi-icon"><mat-icon>people</mat-icon></div>
      </div>
    </div>

    <!-- Refresh info -->
    <div class="refresh-bar">
      <mat-icon>autorenew</mat-icon>
      <span
        >Actualiza cada 30 s · Última actualización:
        {{ lastRefresh() | date: "HH:mm:ss" }}</span
      >
    </div>

    <!-- Tabla -->
    @if (loading()) {
      <div class="loading-overlay">
        <mat-spinner diameter="48"></mat-spinner>
      </div>
    } @else if (payments().length === 0) {
      <div class="empty-state">
        <mat-icon>payments</mat-icon>
        <p>Sin pagos registrados hoy</p>
      </div>
    } @else {
      <mat-card>
        <mat-card-content>
          <table mat-table [dataSource]="payments()">
            <ng-container matColumnDef="hora">
              <th mat-header-cell *matHeaderCellDef>Hora</th>
              <td mat-cell *matCellDef="let r">
                <strong>{{
                  r.createdAt | date: "HH:mm" : "America/Mexico_City"
                }}</strong>
              </td>
            </ng-container>

            <ng-container matColumnDef="cliente">
              <th mat-header-cell *matHeaderCellDef>Cliente</th>
              <td mat-cell *matCellDef="let r">
                <div class="client-name">
                  {{ r.loan?.customer?.fullName || "—" }}
                </div>
                <div class="client-sub">{{ r.loan?.customer?.phone }}</div>
              </td>
            </ng-container>

            <ng-container matColumnDef="monto">
              <th mat-header-cell *matHeaderCellDef>Monto</th>
              <td mat-cell *matCellDef="let r">
                <strong style="color:#1C4532">{{
                  r.amountPaid | currency: "MXN"
                }}</strong>
              </td>
            </ng-container>

            <ng-container matColumnDef="capital">
              <th mat-header-cell *matHeaderCellDef>Capital</th>
              <td mat-cell *matCellDef="let r">
                {{ r.capitalApplied | currency: "MXN" }}
              </td>
            </ng-container>

            <ng-container matColumnDef="interes">
              <th mat-header-cell *matHeaderCellDef>Interés</th>
              <td mat-cell *matCellDef="let r">
                {{ r.interestApplied | currency: "MXN" }}
              </td>
            </ng-container>

            <ng-container matColumnDef="moratorio">
              <th mat-header-cell *matHeaderCellDef>Moratorio</th>
              <td mat-cell *matCellDef="let r">
                @if (r.lateInterestApplied > 0) {
                  <span style="color:#DC2626;font-weight:600">
                    {{ r.lateInterestApplied | currency: "MXN" }}
                  </span>
                } @else {
                  —
                }
              </td>
            </ng-container>

            <ng-container matColumnDef="forma">
              <th mat-header-cell *matHeaderCellDef>Forma</th>
              <td mat-cell *matCellDef="let r">{{ r.method }}</td>
            </ng-container>

            <ng-container matColumnDef="folio">
              <th mat-header-cell *matHeaderCellDef>Folio</th>
              <td
                mat-cell
                *matCellDef="let r"
                style="font-size:11px;color:#718096"
              >
                {{ r.receiptNumber || r.id?.substring(0, 8).toUpperCase() }}
              </td>
            </ng-container>

            <ng-container matColumnDef="ticket">
              <th mat-header-cell *matHeaderCellDef></th>
              <td mat-cell *matCellDef="let r">
                <button
                  mat-icon-button
                  color="primary"
                  (click)="printTicket(r.id)"
                  matTooltip="Imprimir ticket (80mm)"
                >
                  <mat-icon>receipt_long</mat-icon>
                </button>
                <button
                  mat-icon-button
                  (click)="downloadReceipt(r.id)"
                  matTooltip="Comprobante (carta)"
                >
                  <mat-icon>description</mat-icon>
                </button>
                <button
                  mat-icon-button
                  class="wa-icon-btn"
                  (click)="compartirWhatsApp(r)"
                  [disabled]="!telefonoDe(r)"
                  [matTooltip]="
                    telefonoDe(r)
                      ? 'Enviar comprobante por WhatsApp'
                      : 'Sin teléfono registrado'
                  "
                >
                  <mat-icon>share</mat-icon>
                </button>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="cols; sticky: true"></tr>
            <tr mat-row *matRowDef="let row; columns: cols"></tr>

            <!-- Fila de totales (7 columnas: hora,cliente,monto,moratorio,forma,folio,ticket) -->
            <tr class="totals-row">
              <td colspan="2"><strong>TOTALES</strong></td>
              <td>
                <strong>{{ totalCollected() | currency: "MXN" }}</strong>
              </td>
              <td style="color:#DC2626;font-weight:600">
                {{ totalLate() | currency: "MXN" }}
              </td>
              <td colspan="3"></td>
            </tr>
          </table>
        </mat-card-content>
      </mat-card>
      @if (printing()) {
        <div class="loading-overlay">
          <mat-spinner diameter="60"></mat-spinner>

          <div class="loading-text">Enviando ticket a la impresora...</div>
        </div>
      }
    }
  `,
  styles: [
    `
      .header-actions {
        display: flex;
        gap: 10px;
      }

      .kpi-row {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 16px;
        margin-bottom: 16px;
      }
      @media (max-width: 900px) {
        .kpi-row {
          grid-template-columns: 1fr 1fr;
        }
      }
      .kpi {
        border-radius: 16px;
        padding: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
      }
      .kpi-green {
        background: linear-gradient(135deg, #1c4532, #276749);
      }
      .kpi-blue {
        background: linear-gradient(135deg, #4f7af8, #6b5ce7);
      }
      .kpi-amber {
        background: linear-gradient(135deg, #f59e0b, #d97706);
      }
      .kpi-purple {
        background: linear-gradient(135deg, #9b59b6, #6b5ce7);
      }
      .kpi-left {
        flex: 1;
      }
      .kpi-label {
        font-size: 12px;
        color: rgba(255, 255, 255, 0.75);
        margin-bottom: 4px;
      }
      .kpi-value {
        font-size: 28px;
        font-weight: 700;
        color: #fff;
        line-height: 1;
        margin-bottom: 6px;
      }
      .kpi-sub {
        font-size: 11px;
        color: rgba(255, 255, 255, 0.6);
      }
      .kpi-icon {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        background: rgba(255, 255, 255, 0.15);
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .kpi-icon mat-icon {
        color: #fff !important;
        font-size: 22px;
        width: 22px;
        height: 22px;
      }

      .refresh-bar {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        color: #718096;
        margin-bottom: 12px;
      }
      .refresh-bar mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
      }

      .client-name {
        font-weight: 600;
        font-size: 13px;
      }
      .client-sub {
        font-size: 11px;
        color: #718096;
      }

      .totals-row td {
        padding: 10px 16px;
        font-size: 13px;
        border-top: 2px solid #1c4532;
        background: #f0fff4;
      }
    `,
  ],
})
export class PaymentsMonitorComponent implements OnInit, OnDestroy {
  private api = inject(ApiService);
  private pdfSvc = inject(PdfDownloadService);
  private snackbar = inject(MatSnackBar);
  printing = signal(false);

  payments = signal<any[]>([]);
  loading = signal(true);
  lastRefresh = signal<Date>(new Date());

  cols = ["hora", "cliente", "monto", "moratorio", "forma", "folio", "ticket"];

  private sub?: Subscription;

  today = () =>
    new Date().toLocaleDateString("es-MX", { day: "2-digit", month: "long" });
  totalCollected = () =>
    this.payments().reduce((s, p) => s + Number(p.amountPaid), 0);
  totalCapital = () =>
    this.payments().reduce((s, p) => s + Number(p.capitalApplied || 0), 0);
  totalInterest = () =>
    this.payments().reduce((s, p) => s + Number(p.interestApplied || 0), 0);
  totalLate = () =>
    this.payments().reduce((s, p) => s + Number(p.lateInterestApplied || 0), 0);
  uniqueCustomers = () =>
    new Set(this.payments().map((p) => p.loan?.customerId)).size;

  ngOnInit() {
    this.loadPayments();
    this.sub = interval(30000).subscribe(() => this.loadPayments());
  }

  ngOnDestroy() {
    this.sub?.unsubscribe();
  }

  loadPayments() {
    this.loading.set(true);
    this.api.get<any>("/payments/today").subscribe({
      next: (r) => {
        this.payments.set(Array.isArray(r) ? r : (r?.data ?? []));
        this.lastRefresh.set(new Date());
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  // Descargar comprobante carta
  downloadReceipt(id: string) {
    this.pdfSvc.download(
      `/payments/${id}/receipt`,
      `comprobante-${id.substring(0, 8)}.pdf`,
    );
  }


    // ── WhatsApp (mismo formato del monitor) ──
  telefonoDe(p: any): string | null {
    const raw = p?.loan?.customer?.phone;
    if (!raw) return null;
    const d = String(raw).replace(/\D/g, "");
    return d.length >= 10 ? d : null;
  }

  private waNumero(p: any): string | null {
    const tel = this.telefonoDe(p);
    if (!tel) return null;
    if (tel.length === 12 && tel.startsWith("52")) return tel;
    if (tel.length === 10) return "52" + tel;
    return tel;
  }

  private textoTicket(p: any): string {
    const money = (v: any) =>
      "$" +
      (Number(v) || 0).toLocaleString("es-MX", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
    const cliente = p?.loan?.customer?.fullName || "Cliente";
    const folio =
      p?.receiptNumber || (p?.id ? p.id.substring(0, 8).toUpperCase() : "—");
    const fh = this.fmtFecha(p?.createdAt);
    const L: string[] = [];
    L.push("*MICROCAPITAL - IXTEPEC*");
    L.push("COMPROBANTE DE PAGO");
    L.push("--------------------------------");
    L.push(`Folio: ${folio}`);
    L.push(`Cliente: ${cliente}`);
    L.push("--------------------------------");
    /*if (p?.capitalApplied != null)
      L.push(`Capital: ${money(p.capitalApplied)}`);
    if (p?.interestApplied != null)
      L.push(`Interés: ${money(p.interestApplied)}`);*/
    if (Number(p?.lateInterestApplied || 0) > 0)
      L.push(`Moratorio: ${money(p.lateInterestApplied)}`);
    try {
      const cuotas =
        typeof p?.cuotasPagadas === "string"
          ? JSON.parse(p.cuotasPagadas)
          : p?.cuotasPagadas || [];

      if (cuotas.length > 0) {
        L.push("Cuotas pagadas:");

        cuotas
          .sort((a: any, b: any) => a.periodo - b.periodo)
          .forEach((c: any) => {
            L.push(`• #${c.periodo} (${c.fecha})`);
          });

      }
    } catch {}
    L.push(`*TOTAL RECIBIDO: ${money(p?.amountPaid)}*`);
    if (Number(p?.saldoFavor || 0) > 0) {
      L.push(`Saldo a favor: ${money(p.saldoFavor)}`);
    }
    if (p?.method) L.push(`Forma de pago: ${p.method}`);
    L.push(`Fecha y hora: ${fh}`);
    L.push("--------------------------------");
    L.push("Gracias por su pago.");
    return L.join("\n");
  }

  fmtFecha(iso: string): string {
    try {
      return new Intl.DateTimeFormat("es-MX", {
        timeZone: "America/Mexico_City",
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      })
        .format(new Date(iso))
        .replace(",", "");
    } catch {
      return iso;
    }
  }

  /** Abre WhatsApp con el comprobante prellenado al número del cliente. */
  compartirWhatsApp(p: any) {
    const numero = this.waNumero(p);
    if (!numero) {
      this.snackbar.open("El cliente no tiene teléfono válido", "Cerrar", {
        duration: 4000,
      });
      return;
    }
    const url = `https://wa.me/${numero}?text=${encodeURIComponent(this.textoTicket(p))}`;
    const ventana = window.open(url, "_blank");

    // Detectar si el navegador bloqueó la ventana emergente.
    if (!ventana || ventana.closed || typeof ventana.closed === "undefined") {
      // Bloqueado: ofrecer reintento con un clic (acción directa del usuario,
      // que el navegador sí permite).
      const ref = this.snackbar.open(
        "El navegador bloqueó WhatsApp. Toca para abrirlo.",
        "Abrir WhatsApp",
        { duration: 8000 },
      );
      ref.onAction().subscribe(() => window.open(url, "_blank"));
    }
  }

  // ── Reimpresión / comprobante (mismo patrón del monitor) ──
  printTicket(id: string) {
    this.printing.set(true);

    this.api.get<any>(`/payments/${id}/ticket-data`).subscribe({
      next: async (data) => {
        try {
          const resp = await fetch("http://localhost:3100/print-ticket", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              data,
            }),
          });

          const result = await resp.json();

          if (!result.ok) {
            throw new Error(result.message || "Error al imprimir");
          }

          this.snackbar.open("Ticket enviado a impresión", "OK", {
            duration: 2500,
          });
        } catch (e: any) {
          this.snackbar.open(e.message || "Error al imprimir", "Cerrar", {
            duration: 4000,
          });
        } finally {
          this.printing.set(false);
        }
      },
      error: () => {
        this.printing.set(false);

        this.snackbar.open(
          "No se pudieron obtener los datos del ticket",
          "Cerrar",
          { duration: 4000 },
        );
      },
    });
  }

  exportExcel() {
    const fecha = new Date().toISOString().split("T")[0];
    const fechaLeg = new Date().toLocaleDateString("es-MX", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
    const cur = (v: number) =>
      "$" +
      v.toLocaleString("es-MX", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });

    const html = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns="http://www.w3.org/TR/REC-html40">
      <head><meta charset="UTF-8">
      <!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets>
        <x:ExcelWorksheet><x:Name>Pagos del día</x:Name>
        <x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions>
        </x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
      <style>
        body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; }
        .title {
          background: #1C4532; color: #ffffff;
          font-size: 16pt; font-weight: bold;
          text-align: center; padding: 10px;
        }
        .subtitle {
          background: #276749; color: #d1fae5;
          font-size: 10pt; text-align: center; padding: 6px;
        }
        .meta {
          background: #F0FFF4; color: #1C4532;
          font-size: 9pt; text-align: center; padding: 4px;
          border-bottom: 2px solid #1C4532;
        }
        .spacer { height: 8px; }
        th {
          background: #1C4532; color: #ffffff;
          font-weight: bold; font-size: 10pt;
          padding: 8px 10px; text-align: center;
          border: 1px solid #0d2b1e;
        }
        td {
          padding: 6px 10px; font-size: 10pt;
          border: 1px solid #CBD5E0; vertical-align: middle;
        }
        .row-even { background: #F0FFF4; }
        .row-odd  { background: #ffffff; }
        .col-num  { text-align: right; font-family: Consolas, monospace; }
        .col-mora { text-align: right; color: #DC2626; font-weight: 600; font-family: Consolas, monospace; }
        .col-hora { text-align: center; font-weight: 600; color: #1C4532; }
        .col-folio{ font-family: Consolas, monospace; font-size: 9pt; color: #718096; }
        .totals td {
          background: #1C4532; color: #ffffff;
          font-weight: bold; font-size: 10pt;
          border: 1px solid #0d2b1e;
        }
        .totals .col-label {
          text-align: left; letter-spacing: 1px;
        }
        table { border-collapse: collapse; width: 100%; }
      </style>
      </head><body>
      <table>
        <tr><td colspan="9" class="title">REPORTE DE PAGOS DEL DÍA — MICROCAPITAL IXTEPEC</td></tr>
        <tr><td colspan="9" class="subtitle">${fechaLeg}</td></tr>
        <tr><td colspan="9" class="meta">
          Total de pagos: ${this.payments().length} &nbsp;|&nbsp;
          Total cobrado: ${cur(this.totalCollected())} &nbsp;|&nbsp;
          Capital: ${cur(this.totalCapital())} &nbsp;|&nbsp;
          Interés: ${cur(this.totalInterest())} &nbsp;|&nbsp;
          Moratorio: ${cur(this.totalLate())}
        </td></tr>
        <tr class="spacer"><td colspan="9"></td></tr>
        <tr>
          <th>Hora</th><th>Cliente</th><th>Teléfono</th>
          <th>Monto recibido</th><th>Capital</th><th>Interés</th>
          <th>Moratorio</th><th>Forma de pago</th><th>Folio</th>
        </tr>
        ${this.payments()
          .map(
            (p, i) => `
        <tr class="${i % 2 === 0 ? "row-even" : "row-odd"}">
          <td class="col-hora">${new Date(p.paymentDate).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" })}</td>
          <td><b>${p.loan?.customer?.fullName || "—"}</b></td>
          <td>${p.loan?.customer?.phone || "—"}</td>
          <td class="col-num">${cur(Number(p.amountPaid))}</td>
          <td class="col-num">${cur(Number(p.capitalApplied || 0))}</td>
          <td class="col-num">${cur(Number(p.interestApplied || 0))}</td>
          <td class="${Number(p.lateInterestApplied || 0) > 0 ? "col-mora" : "col-num"}">
            ${Number(p.lateInterestApplied || 0) > 0 ? cur(Number(p.lateInterestApplied)) : "—"}
          </td>
          <td style="text-align:center">${p.method || "EFECTIVO"}</td>
          <td class="col-folio">${p.receiptNumber || p.id?.substring(0, 8).toUpperCase()}</td>
        </tr>`,
          )
          .join("")}
        <tr class="totals">
          <td class="col-label" colspan="3">TOTALES</td>
          <td class="col-num">${cur(this.totalCollected())}</td>
          <td class="col-num">${cur(this.totalCapital())}</td>
          <td class="col-num">${cur(this.totalInterest())}</td>
          <td class="col-num">${cur(this.totalLate())}</td>
          <td colspan="2"></td>
        </tr>
      </table>
      </body></html>`;

    const blob = new Blob([html], {
      type: "application/vnd.ms-excel;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `reporte-pagos-${fecha}.xls`;
    a.click();
    URL.revokeObjectURL(url);
    this.snackbar.open("Reporte exportado correctamente", "OK", {
      duration: 2000,
    });
  }
}
